# DolibarrPickup

## Fonctionnalités

Il s'agit d'un module pour l'ERP/CRM [Dolibarr](https://www.dolibarr.org/) destiné à gérer les collectes de certaines ressourceries.

Le projet a été créé à l'origine pour [La Ressourcerie Du Spectacle](https://www.ressourcerieduspectacle.fr).

Si vous êtes intéressé⋅e⋅s par ce module et souhaitez l'adapter à vos propres besoins,
n'hésitez pas à contacter John Livingston via l'un des dépots d'origine :

- https://github.com/JohnXLivingston/DolibarrPickup
- https://code.globenet.org/john/DolibarrPickup

Le code est publié sous licence [GNU Affero General Public License 3](./COPYING).

Bien que conçu et maintenu pour des associations françaises, le projet est multilangue, et peut être aisément traduit (la traduction anglaise US est maintenue en même temps que la française).
