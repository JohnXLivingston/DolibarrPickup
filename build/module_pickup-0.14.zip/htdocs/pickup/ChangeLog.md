# DolibarrPickup

## 0.14

### Fonctionnalités

* Appli mobile : refonte graphique complète (utilisation de Bootstap).

### Corrections mineures

* Clean du code.

## 0.13

### Fonctionnalités

* Appli mobile : si on a le droit «Create pickups», on liste toutes les collectes en cours.
* Appli mobile : l'écran d'accueil devient le choix de la collecte.
* Liste des collectes : affichage du nombre de produits (DEEE vs non DEEE).

### Corrections mineures

* Mise à jour des dépendances npm
* Appli mobile : traductions des erreurs de ssaisie
* Appli mobile : Changements de certains libellés pour LRDS.
* Tags / onglet Collecte : correctif de l'écran. Certains libellés n'étaient pas affichés, ou étaient incorrect.
* Nettoyage du code (diverses modifications).
* Ajout de StateVirtual.
* Appli mobile : le champs «Notes» devient «Description» (et n'est plus stocké dans les notes privées).
* Modification de libellé sur la fiche collecte : «Date» => «Date de la collecte»
* Formulaire de création de collecte : on retire le statut.

## 0.12

Initial version. Released for LaRessourcerieDuSpectacle.
