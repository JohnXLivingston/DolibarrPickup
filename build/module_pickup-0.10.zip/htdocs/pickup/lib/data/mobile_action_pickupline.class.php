<?php
dol_include_once('/pickup/lib/data/mobile_action.class.php');

class DataMobileActionPickupline extends DataMobileAction {
  // TODO
  // public function action_save() {
  //   dol_syslog(__METHOD__, LOG_DEBUG);
  //   global $user;

  //   dol_include_once('/pickup/class/pickup.class.php');
  //   dol_include_once('/pickup/class/pickupline.class.php');
    
  // }
}
